# This file is used to make this directory as package please do not delete it.
# This package contains the routes for home and about pages.